
#ifndef _UISEPARATOR_H_
#define _UISEPARATOR_H_

#include <Framework/Controls/Control.h>

namespace suic
{

class SUICORE_API Separator : public Control
{
public:

    Separator();
    ~Separator();

    RTTIOfClass(Separator)
};

};

#endif
