// ���ڿƼ���Ȩ���� 2010-2011
// 
// �ļ�����Popup.h
// ��  �ܣ�ʵ�ֱ�׼�ĵ������ڣ��޽��㣩��
// 
// ��  �ߣ�MPF������
// ʱ  �䣺2010-07-02
// 
// ============================================================================

#ifndef _UIPOPUP_H_
#define _UIPOPUP_H_

#include <Framework/Controls/Content.h>

namespace suic
{

enum PlacementMode
{
    pmLeft,
    pmTop,
    pmRight,
    pmBottom,
    pmCenter,
    pmMouse,
    pmMousePoint,
    pmCustom,
};

struct SUICORE_API PlacementModeBox
{
    static Integer* LeftBox;
    static Integer* TopBox;
    static Integer* RightBox;
    static Integer* BottomBox;
    static Integer* CenterBox;
    static Integer* MouseBox;
    static Integer* MousePointBox;
    static Integer* CustomBox;

    static Integer* From(int index);
};

struct PositionInfo
{
    int x;
    int y;
    fSize ChildSize;
    Rect MouseRect;
};

class SUICORE_API PopupRoot : public FrameworkElement
{
public:

    PopupRoot();
    ~PopupRoot();

    RTTIOfClass(PopupRoot)

    Element* GetChild();
    void SetChild(Element* elem);

    int GetVisualChildrenCount();
    Element* GetVisualChild(int index);

    Element* GetLogicalChild(int index);
    int GetLogicalChildrenCount();

protected:

    void SetupLayoutBindings(Popup* popup);
    fSize ComputeChildDesiredSize(fSize restrictedSize);
    fSize ComputePopupSizeRestrictions(Popup* popup, fSize desiredSize, bool& bWidth, bool& bHeight);

    friend class Popup;

public:

    fSize OnMeasure(const fSize& constraintSize);
    void OnArrange(const fSize& arrangeSize);

    void OnKeyDown(KeyboardEventArg* e);

private:  

    Element* _child;
};

class OpeningEventArg : public EventArg
{
public:

    OpeningEventArg(HwndParam* hp)
        : _hp(hp)
    {
    }

    HwndParam* GetHwndParam() const
    {
        return _hp;
    }

private:

    HwndParam* _hp;
};

typedef delegate<void(Object*, OpeningEventArg*), suic::UnrefObj> OpeningEventHandler;

class SUICORE_API Popup : public FrameworkElement, public IAddChild
{
public:

    EventHandler Closed;
    EventHandler Opened;
    EventHandler Closing;
    OpeningEventHandler Opening;

    static DpProperty* ChildProperty;
    static DpProperty* IsOpenProperty;
    static DpProperty* CoercedPosProperty;
    static DpProperty* PlacementProperty;
    static DpProperty* PlacementRectangleProperty;
    static DpProperty* PlacementTargetProperty;
    static DpProperty* VerticalOffsetProperty;
    static DpProperty* HorizontalOffsetProperty;
    static DpProperty* AllowsTransparencyProperty;

    static bool StaticInit();
    static void CreateRootPopup(Popup* popup, Element* child);

    static void OnChildPropChanged(DpObject* d, DpPropChangedEventArg* e);
    static void OnIsOpenPropChanged(DpObject* d, DpPropChangedEventArg* e);
    static void OnPlacementPropChanged(DpObject* d, DpPropChangedEventArg* e);
    static void OnOffsetPropChanged(DpObject* d, DpPropChangedEventArg* e);
    static void OnPlacementTargetPropChanged(DpObject* d, DpPropChangedEventArg* e);
    static void OnAllowsTransparencyPropChanged(DpObject* d, DpPropChangedEventArg* e);

    Popup();
    ~Popup();

    RTTIOfClass(Popup)

    void Hide();
    void Show(Point pt);
    void Close();
    void AsyncClose();
    bool IsClosing();

    PopupRoot* GetPopupRoot();
    PositionInfo* GetPositionInfo();

    Element* GetChild();
    void SetChild(Element* elem);

    void InvalidatePopupRoot();
    void TrackingPopup(MessageHook& hook=MessageHook());

    bool IsOpen();
    void SetIsOpen(bool val);

    bool GetCoercedPos();
    void SetCoercedPos(bool val);

    PlacementMode GetPlacement();
    void SetPlacement(PlacementMode val);

    Rect GetPlacementRectangle();
    void GetPlacementRectangle(Rect val);

    Element* GetPlacementTarget();
    void SetPlacementTarget(Element* target);

    int GetVerticalOffset();
    void SetVerticalOffset(int val);

    int GetHorizontalOffset();
    void SetHorizontalOffset(int val);

    bool AllowsTransparency();
    void SetAllowsTransparency(bool val);

    bool IsChildPopup();
    void SetChildPopup(bool value);

    Popup* GetParentPopup();
    void SetParentPopup(Popup* val);

public:

    void AddChild(Object* obj);
    void AddText(String val);
    void RemoveChild(Object* child);

    virtual void OnClosing(CancelEventArg& e);
    virtual void OnClosed(EventArg* e);
    virtual void OnOpened(EventArg* e);

    virtual bool OnShowingWindow();
    virtual void OnShowWindow();
    virtual void OnHideWindow();

    virtual bool OnFilterMessage(Object* sender, MessageParam* mp, bool& interrupt);
    virtual bool OnSysFilterMessage(Object* sender, MessageParam* mp, bool& interrupt);

protected:
    
    fSize OnMeasure(const fSize& constratint);
    void OnArrange(const fSize& arrangeSize);

    void OnHitTest(HitResultEventArg* e);
    void OnMouseWheel(MouseWheelEventArg* e);

    void OnMouseLeftButtonDown(MouseButtonEventArg* e);
    void OnMouseRightButtonDown(MouseButtonEventArg* e);

protected:

    Element* GetTarget();
    void InternalClose(bool async);
    int InternalCreate(int wid, int hei);
    bool BlockVisualState();
    void EnsurePopupRoot();
    void ComputePosition(fSize desiredSize);

protected:

    bool _onMouseIn;
    bool _onTimer;
    bool _onDownClose;
    bool _isMouseIn;
    bool _isClosing;

    Popup* _parentPopup;
    PopupRoot* _popupRoot;
    AssignerFrame* _frame;
    PositionInfo _positionInfo;
};

typedef shared<Popup> PopupPtr;

}

#endif
